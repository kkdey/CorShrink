#' @title ashr
#' @description The main function in the ashr package is \code{\link{ash}}, which should be examined for more details. For simplicity only the most commonly-used options are documented under \code{\link{ash}}. For expert or interested users the documentation for function \code{\link{ash.workhorse}} provides documentation on all implemented options.
#' @name ashr
#' @docType package
NULL
