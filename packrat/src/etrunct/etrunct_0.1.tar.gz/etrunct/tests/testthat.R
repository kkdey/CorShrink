library(testthat)
library(etrunct)

test_check("etrunct")
