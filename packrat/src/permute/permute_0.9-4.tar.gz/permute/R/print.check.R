`print.check` <- function(x, ...)
{
    print(x$n)
}
