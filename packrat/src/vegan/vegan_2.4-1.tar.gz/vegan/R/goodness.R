"goodness" <-
  function(object, ...) UseMethod("goodness")

