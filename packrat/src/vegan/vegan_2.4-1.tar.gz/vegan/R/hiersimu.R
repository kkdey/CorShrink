hiersimu <-
function (...) 
{
   UseMethod("hiersimu")
}
