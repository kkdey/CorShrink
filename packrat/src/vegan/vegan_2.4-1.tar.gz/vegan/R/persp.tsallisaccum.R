persp.tsallisaccum <- 
function(x, theta = 220, phi = 15, col = heat.colors(100), zlim, ...) 
{
persp.renyiaccum(x, theta = theta, phi = phi, col = col, zlim = zlim, ...)
}
