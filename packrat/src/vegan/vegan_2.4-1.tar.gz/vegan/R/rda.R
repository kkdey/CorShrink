"rda" <-
function (...) 
{
    UseMethod("rda")
}
