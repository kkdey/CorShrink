`str.nullmodel` <-
    function(object, ...) str(as.list(object), ...)
