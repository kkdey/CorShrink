## ----eval=FALSE----------------------------------------------------------
#  sol <- cca(varespec)
#  ef <- envfit(sol ~ ., varechem)
#  plot(sol)
#  ordiArrowMul(scores(ef, display="vectors"))

